/**
 * IT-ERA Sector Personalization System
 * Advanced personalization for medical, legal, and general sectors
 * GDPR compliance and sector-specific knowledge base
 */

class ITERASectorPersonalization {
    constructor() {
        this.sectorProfiles = {
            medical: {
                name: 'Settore Sanitario',
                compliance: ['GDPR Sanitario', 'Privacy Pazienti', 'Sicurezza Dati Clinici'],
                terminology: {
                    data: 'dati clinici',
                    security: 'sicurezza sanitaria',
                    backup: 'backup cartelle cliniche',
                    compliance: 'compliance sanitaria'
                },
                services: [
                    'Gestione cartelle cliniche digitali',
                    'Backup sicuro dati pazienti',
                    'Telemedicina e consulti online',
                    'Sistemi di prenotazione',
                    'Compliance GDPR sanitario'
                ],
                urgencyKeywords: [
                    'paziente', 'emergenza sanitaria', 'dati clinici', 'cartelle',
                    'sistema ospedaliero', 'prenotazioni', 'referto', 'diagnosi'
                ],
                responseTemplates: {
                    greeting: '🏥 Benvenuto nel supporto IT specializzato per il settore sanitario!',
                    urgency: '🚨 **EMERGENZA SANITARIA IT** - Chiama immediatamente: 039 888 2041',
                    compliance: '✅ IT-ERA garantisce piena compliance GDPR sanitario per tutti i servizi medici.',
                    services: 'I nostri servizi specializzati per studi medici e ospedali includono:'
                },
                riskFactors: {
                    dataLoss: 10, // Highest priority
                    systemDown: 9,
                    securityBreach: 10,
                    complianceIssue: 8
                }
            },
            
            legal: {
                name: 'Settore Legale',
                compliance: ['GDPR Legale', 'Riservatezza Documenti', 'Sicurezza Archivi'],
                terminology: {
                    data: 'documenti legali',
                    security: 'riservatezza',
                    backup: 'archiviazione sicura',
                    compliance: 'compliance legale'
                },
                services: [
                    'Archiviazione sicura documenti legali',
                    'Backup e disaster recovery',
                    'Firma digitale e PEC',
                    'Sistemi di gestione pratiche',
                    'Compliance GDPR legale'
                ],
                urgencyKeywords: [
                    'causa', 'scadenza', 'tribunale', 'documenti legali', 'contratto',
                    'pratica', 'udienza', 'sentenza', 'archivio', 'riservatezza'
                ],
                responseTemplates: {
                    greeting: '⚖️ Benvenuto nel supporto IT specializzato per studi legali!',
                    urgency: '🚨 **EMERGENZA LEGALE IT** - Chiama immediatamente: 039 888 2041',
                    compliance: '✅ IT-ERA assicura massima riservatezza e compliance GDPR per studi legali.',
                    services: 'I nostri servizi specializzati per studi legali includono:'
                },
                riskFactors: {
                    dataLoss: 9,
                    systemDown: 8,
                    securityBreach: 10, // Highest for legal
                    complianceIssue: 9
                }
            },
            
            general: {
                name: 'Settore Generale',
                compliance: ['GDPR Generale', 'Sicurezza Aziendale', 'Privacy Dipendenti'],
                terminology: {
                    data: 'dati aziendali',
                    security: 'sicurezza informatica',
                    backup: 'backup aziendale',
                    compliance: 'compliance GDPR'
                },
                services: [
                    'Assistenza IT completa 24/7',
                    'Cybersecurity aziendale',
                    'Cloud storage e backup',
                    'VoIP e centralino cloud',
                    'Consulenza IT strategica'
                ],
                urgencyKeywords: [
                    'business', 'produzione', 'vendite', 'ufficio', 'dipendenti',
                    'server', 'rete', 'email', 'sistema aziendale'
                ],
                responseTemplates: {
                    greeting: '💼 Benvenuto nel supporto IT per aziende lombarde!',
                    urgency: '🚨 **EMERGENZA IT AZIENDALE** - Chiama immediatamente: 039 888 2041',
                    compliance: '✅ IT-ERA garantisce compliance GDPR per tutte le aziende.',
                    services: 'I nostri servizi IT aziendali includono:'
                },
                riskFactors: {
                    dataLoss: 7,
                    systemDown: 8,
                    securityBreach: 8,
                    complianceIssue: 6
                }
            }
        };
        
        this.init();
    }
    
    init() {
        console.log('🎯 IT-ERA Sector Personalization System initialized');
        
        // Integrate with existing AI system
        if (window.ITERA_AI) {
            window.ITERA_AI.sectorPersonalization = this;
        }
    }
    
    // Enhanced sector detection with confidence scoring
    detectSector(message, context = {}) {
        const text = message.toLowerCase();
        const sectorScores = {};
        
        // Calculate scores for each sector
        for (const [sectorKey, sectorData] of Object.entries(this.sectorProfiles)) {
            let score = 0;
            
            // Check urgency keywords (higher weight)
            sectorData.urgencyKeywords.forEach(keyword => {
                if (text.includes(keyword.toLowerCase())) {
                    score += 5;
                }
            });
            
            // Check compliance keywords
            sectorData.compliance.forEach(keyword => {
                if (text.includes(keyword.toLowerCase())) {
                    score += 3;
                }
            });
            
            // Check service keywords
            sectorData.services.forEach(service => {
                const serviceWords = service.toLowerCase().split(' ');
                serviceWords.forEach(word => {
                    if (word.length > 3 && text.includes(word)) {
                        score += 2;
                    }
                });
            });
            
            // Context-based scoring
            if (context.previousSector === sectorKey) {
                score += 2; // Continuity bonus
            }
            
            if (context.userAgent && context.userAgent.includes('Mobile')) {
                // Mobile users might be in urgent situations
                if (sectorKey === 'medical') score += 1;
            }
            
            sectorScores[sectorKey] = score;
        }
        
        // Find sector with highest score
        const sortedSectors = Object.entries(sectorScores)
            .sort(([,a], [,b]) => b - a);
        
        const bestMatch = sortedSectors[0];
        const confidence = bestMatch[1] / Math.max(1, Math.max(...Object.values(sectorScores)));
        
        return {
            sector: bestMatch[1] > 0 ? bestMatch[0] : 'general',
            confidence: confidence,
            scores: sectorScores,
            alternatives: sortedSectors.slice(1, 3).map(([sector, score]) => ({
                sector,
                score,
                confidence: score / Math.max(1, bestMatch[1])
            }))
        };
    }
    
    // Generate personalized response based on sector
    personalizeResponse(baseResponse, sector, analysis = {}) {
        const sectorProfile = this.sectorProfiles[sector] || this.sectorProfiles.general;
        let personalizedResponse = baseResponse;
        
        // Add sector-specific greeting if it's the first message
        if (analysis.isFirstMessage) {
            personalizedResponse = `${sectorProfile.responseTemplates.greeting}\n\n${personalizedResponse}`;
        }
        
        // Add urgency handling
        if (analysis.urgencyLevel === 'critical') {
            personalizedResponse = `${sectorProfile.responseTemplates.urgency}\n\n${personalizedResponse}`;
        }
        
        // Replace generic terms with sector-specific terminology
        for (const [generic, specific] of Object.entries(sectorProfile.terminology)) {
            const regex = new RegExp(`\\b${generic}\\b`, 'gi');
            personalizedResponse = personalizedResponse.replace(regex, specific);
        }
        
        // Add compliance note if not present
        if (!personalizedResponse.includes('GDPR') && !personalizedResponse.includes('compliance')) {
            personalizedResponse += `\n\n${sectorProfile.responseTemplates.compliance}`;
        }
        
        // Add sector-specific services if relevant
        if (analysis.intent === 'service_inquiry' || analysis.recommendedService) {
            personalizedResponse += `\n\n${sectorProfile.responseTemplates.services}`;
            sectorProfile.services.slice(0, 3).forEach((service, index) => {
                personalizedResponse += `\n${index + 1}. ${service}`;
            });
        }
        
        return personalizedResponse;
    }
    
    // Calculate risk score based on sector and message content
    calculateRiskScore(message, sector, urgencyAnalysis) {
        const sectorProfile = this.sectorProfiles[sector] || this.sectorProfiles.general;
        const text = message.toLowerCase();
        
        let riskScore = urgencyAnalysis.score || 0;
        
        // Apply sector-specific risk factors
        if (text.includes('perso') || text.includes('cancellato')) {
            riskScore += sectorProfile.riskFactors.dataLoss;
        }
        
        if (text.includes('down') || text.includes('non funziona')) {
            riskScore += sectorProfile.riskFactors.systemDown;
        }
        
        if (text.includes('hacker') || text.includes('virus') || text.includes('sicurezza')) {
            riskScore += sectorProfile.riskFactors.securityBreach;
        }
        
        if (text.includes('gdpr') || text.includes('privacy') || text.includes('compliance')) {
            riskScore += sectorProfile.riskFactors.complianceIssue;
        }
        
        return {
            score: riskScore,
            level: riskScore >= 15 ? 'critical' : 
                   riskScore >= 10 ? 'high' : 
                   riskScore >= 5 ? 'medium' : 'low',
            factors: this.identifyRiskFactors(text, sectorProfile)
        };
    }
    
    identifyRiskFactors(text, sectorProfile) {
        const factors = [];
        
        if (text.includes('perso') || text.includes('cancellato')) {
            factors.push('data_loss');
        }
        if (text.includes('down') || text.includes('non funziona')) {
            factors.push('system_down');
        }
        if (text.includes('hacker') || text.includes('virus')) {
            factors.push('security_breach');
        }
        if (text.includes('gdpr') || text.includes('privacy')) {
            factors.push('compliance_issue');
        }
        
        return factors;
    }
    
    // Get sector-specific knowledge base
    getSectorKnowledge(sector) {
        return this.sectorProfiles[sector] || this.sectorProfiles.general;
    }
    
    // Generate sector-specific recommendations
    generateRecommendations(sector, analysis) {
        const sectorProfile = this.sectorProfiles[sector] || this.sectorProfiles.general;
        const recommendations = [];
        
        // Urgency-based recommendations
        if (analysis.urgencyLevel === 'critical') {
            recommendations.push({
                type: 'immediate_action',
                title: 'Contatto Immediato',
                description: 'Chiama subito 039 888 2041 per assistenza prioritaria',
                priority: 1
            });
        }
        
        // Sector-specific service recommendations
        if (analysis.recommendedService) {
            const relevantServices = sectorProfile.services.filter(service =>
                service.toLowerCase().includes(analysis.recommendedService.toLowerCase())
            );
            
            relevantServices.forEach((service, index) => {
                recommendations.push({
                    type: 'service_recommendation',
                    title: service,
                    description: `Servizio specializzato per ${sectorProfile.name}`,
                    priority: index + 2
                });
            });
        }
        
        return recommendations.sort((a, b) => a.priority - b.priority);
    }
}

// Initialize sector personalization system
window.ITERASectorPersonalization = new ITERASectorPersonalization();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = ITERASectorPersonalization;
}

console.log('🎯 IT-ERA Sector Personalization System loaded');
